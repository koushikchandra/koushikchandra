# Koushik Chandra Howlader — Academic Website

This is a simple, responsive academic portfolio prepared for **https://koushikchandra.github.io/**. It uses only HTML, CSS, and JavaScript; no installation or framework is required.

## Website sections

- About
- Research interests
- Education
- Publications and projects
- Academic experience
- Contact information
- Downloadable CV

## Folder structure

```text
koushikchandra.github.io/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    ├── Koushik_Howlader_CV.pdf
    └── profile.jpg
```

## Customize the website

1. Open `index.html` and replace `YOUR_EMAIL@iastate.edu` with your email.
2. Replace the placeholder `#` links with your Google Scholar and LinkedIn URLs.
3. Put your CV in `assets/` and name it `Koushik_Howlader_CV.pdf`.
4. Put your photograph in `assets/` as `profile.jpg`.
5. Replace the `KH` portrait block in `index.html` with:

```html
<img class="portrait profile-photo" src="assets/profile.jpg" alt="Koushik Chandra Howlader">
```

6. Add this line at the bottom of `style.css`:

```css
.profile-photo { object-fit: cover; }
```

7. Verify all publication names, dates, experience, and links before publishing.

## Preview on your computer

Extract the ZIP and double-click `index.html`.

## Publish with GitHub Pages

1. Create a new **public** GitHub repository named exactly `koushikchandra.github.io`.
2. Upload all files and the `assets` folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose `main` and `/(root)`, then click **Save**.

The published website will appear at **https://koushikchandra.github.io/**. Future commits will update it automatically.
